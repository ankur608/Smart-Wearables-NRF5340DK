/*
 * Copyright (c) 2019 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr.h>
#include <device.h>
#include <drivers/sensor.h>
#include <stdio.h>

float a,b,c,d,e,f;

static int process_mpu6050(const struct device *dev)
{
	struct sensor_value temperature;
	struct sensor_value accel[3];
	struct sensor_value gyro[3];
	int rc = sensor_sample_fetch(dev);

	if (rc == 0) {
		rc = sensor_channel_get(dev, SENSOR_CHAN_ACCEL_XYZ,
					accel);
	}
	if (rc == 0) {
		rc = sensor_channel_get(dev, SENSOR_CHAN_GYRO_XYZ,
					gyro);
	}
	if (rc == 0) {
		rc = sensor_channel_get(dev, SENSOR_CHAN_AMBIENT_TEMP,
					&temperature);
	}
	if (rc == 0) {
                       /*
                       printf("%.2f00, %.2f00, %.2f00, %.2f00, %.2f00, %.2f00\n",
                            sensor_value_to_double(&accel[0]),
                            sensor_value_to_double(&accel[1]),
                            sensor_value_to_double(&accel[2]),
                            sensor_value_to_double(&gyro[0]),
                            sensor_value_to_double(&gyro[1]),
                            sensor_value_to_double(&gyro[2]));
                       */
        //float features[] = {printf("%.02f00",sensor_value_to_double(&accel[0])), printf(", "), printf("%.02f00",sensor_value_to_double(&accel[1])), printf(", "), printf("%.02f00",sensor_value_to_double(&accel[2])), printf(", "), printf("%.02f00",sensor_value_to_double(&gyro[0])), printf(", "), printf("%.02f00",sensor_value_to_double(&gyro[1])), printf(", "), printf("%.02f0",sensor_value_to_double(&gyro[2])), printf("")};
        //printf("%.0f\n", (&features[5]));
	float features[] = {printf("%.02f00",sensor_value_to_double(&accel[0])), printf(", "),
                            printf("%.02f00",sensor_value_to_double(&accel[1])), printf(", "),
                            printf("%.02f00",sensor_value_to_double(&accel[2])), printf(", "),
                            printf("%.02f00",sensor_value_to_double(&gyro[0])), printf(", "),
                            printf("%.02f00",sensor_value_to_double(&gyro[1])), printf(", "),
                            printf("%.02f0",sensor_value_to_double(&gyro[2])), printf("")};
                            printf("%.0f\n", (&features[66]));

                            a = printf("%.2f00",sensor_value_to_double(&accel[0]));
                            b = printf("%.2f00",sensor_value_to_double(&accel[1]));
                            printf("%.0f, %.0f\n", &a, &b);

        } else {
		//printf("sample fetch/get failed: %d\n", rc);
                printf("0,0,0,0,0,0", rc);
	}

	return rc;
}

#ifdef CONFIG_MPU6050_TRIGGER
static struct sensor_trigger trigger;

static void handle_mpu6050_drdy(const struct device *dev,
				struct sensor_trigger *trig)
{
	int rc = process_mpu6050(dev);

	if (rc != 0) {
		printf("cancelling trigger due to failure: %d\n", rc);
		(void)sensor_trigger_set(dev, trig, NULL);
		return;
	}
}
#endif /* CONFIG_MPU6050_TRIGGER */

void main(void)
{
	const char *const label = DT_LABEL(DT_INST(0, invensense_mpu6050));
	const struct device *mpu6050 = device_get_binding(label);

	if (!mpu6050) {
		printf("Failed to find sensor %s\n", label);
		return;
	}

#ifdef CONFIG_MPU6050_TRIGGER
	trigger = (struct sensor_trigger) {
		.type = SENSOR_TRIG_DATA_READY,
		.chan = SENSOR_CHAN_ALL,
	};
	if (sensor_trigger_set(mpu6050, &trigger,
			       handle_mpu6050_drdy) < 0) {
		printf("Cannot configure trigger\n");
		return;
	};
	printk("Configured for triggered sampling.\n");
#endif

	while (!IS_ENABLED(CONFIG_MPU6050_TRIGGER)) {
		int rc = process_mpu6050(mpu6050);

		if (rc != 0) {
			break;
		}
		k_sleep(K_SECONDS(0.1));
	}

	/* triggered runs with its own thread after exit */
}
