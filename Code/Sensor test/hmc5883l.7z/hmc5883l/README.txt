Title: hmc5883l

Description:

A simple example using the hmc5883l 3-axis magnetometer sensor.
