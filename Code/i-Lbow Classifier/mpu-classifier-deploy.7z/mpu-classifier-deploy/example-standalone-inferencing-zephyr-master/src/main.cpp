#include <zephyr.h>
#include <device.h>
#include <drivers/sensor.h>
#include <stdio.h>
#include "ei_run_classifier.h"
#include "numpy.hpp"
struct sensor_value accel[3];
struct sensor_value gyro[3];
float a,b,c,d,e,f;

static int process_mpu6050(const struct device *dev)
{
	struct sensor_value temperature;
	struct sensor_value accel[3];
	struct sensor_value gyro[3];
	int rc = sensor_sample_fetch(dev);

	if (rc == 0) {
		rc = sensor_channel_get(dev, SENSOR_CHAN_ACCEL_XYZ,
					accel);
	}
	if (rc == 0) {
		rc = sensor_channel_get(dev, SENSOR_CHAN_GYRO_XYZ,
					gyro);
	}
	if (rc == 0) {
		rc = sensor_channel_get(dev, SENSOR_CHAN_AMBIENT_TEMP,
					&temperature);
	}
	if (rc == 0) {
		a = printf("%.2f00",sensor_value_to_double(&accel[0])); printf(", ");
		b = printf("%.2f00",sensor_value_to_double(&accel[1])); printf(", ");
		c = printf("%.2f00",sensor_value_to_double(&accel[2])); printf(", ");
		d = printf("%.2f00",sensor_value_to_double(&gyro[0])); printf(", ");
		e = printf("%.2f00",sensor_value_to_double(&gyro[1])); printf(", ");
		f = printf("%.2f00",sensor_value_to_double(&gyro[2])); printf("\n");
	} else {
		//printf("sample fetch/get failed: %d\n", rc);
                //printf("0,0,0,0,0,0", rc);
	}

	return rc;
}

#ifdef CONFIG_MPU6050_TRIGGER
static struct sensor_trigger trigger;

static void handle_mpu6050_drdy(const struct device *dev,
				struct sensor_trigger *trig)
{
	int rc = process_mpu6050(dev);

	if (rc != 0) {
		printf("cancelling trigger due to failure: %d\n", rc);
		(void)sensor_trigger_set(dev, trig, NULL);
		return;
	}
}
#endif /* CONFIG_MPU6050_TRIGGER */

//static const float features[] = {
float features[] = {
   // 8.5500, -5.4900, 0.3900, -0.0200, -0.0100, -0.0100, 8.4500, -5.5000, 0.4000, -0.0100, -0.0200, -0.0200, 8.5100, -5.4600, 0.3800, -0.0100, -0.0100, -0.0100, 8.6000, -5.4400, 0.3900, -0.0200, -0.0400, -0.0100, 8.6100, -5.5300, 0.3800, -0.0300, -0.0300, -0.0300, 8.4600, -5.4300, 0.2100, -0.0500, -0.0700, -0.0100, 6.2000, -4.6900, 0.9500, -0.6000, -0.2200, 0.0300, 6.7900, -2.9700, -2.1200, -0.6600, -0.3600, 0.0800, 8.6400, -5.6600, -0.0900, -0.2700, 0.2500, -0.2400, 9.3300, -5.3900, -0.4300, -0.2100, 0.0200, -0.1600, 8.7600, -5.6000, -0.1600, -0.0100, -0.0900, -0.1100
	printf("%.2f00",sensor_value_to_double(&accel[0])), printf("%.2f00",sensor_value_to_double(&accel[1])), printf("%.2f00",sensor_value_to_double(&accel[2])), printf("%.2f00",sensor_value_to_double(&gyro[0])), printf("%.2f00",sensor_value_to_double(&gyro[1])), printf("%.2f00",sensor_value_to_double(&gyro[2])),
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f,
	a, b, c, d, e, f
};

int raw_feature_get_data(size_t offset, size_t length, float *out_ptr) {
    memcpy(out_ptr, features + offset, length * sizeof(float));
    return 0;
}

int main() {
    // This is needed so that output of printf is output immediately without buffering
    setvbuf(stdout, NULL, _IONBF, 0);

    printk("Edge Impulse standalone inferencing (Zephyr)\n");

    if (sizeof(features) / sizeof(float) != EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE) {
        printk("The size of your 'features' array is not correct. Expected %d items, but had %u\n",
            EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, sizeof(features) / sizeof(float));
        return 1;
    }

    ei_impulse_result_t result = { 0 };
	
	const char *const label = DT_LABEL(DT_INST(0, invensense_mpu6050));
	const struct device *mpu6050 = device_get_binding(label);
/*
	if (!mpu6050) {
		printf("Failed to find sensor %s\n", label);
		return;
	}
*/
	#ifdef CONFIG_MPU6050_TRIGGER
	trigger = (struct sensor_trigger) {
		.type = SENSOR_TRIG_DATA_READY,
		.chan = SENSOR_CHAN_ALL,
	};
	if (sensor_trigger_set(mpu6050, &trigger,
			       handle_mpu6050_drdy) < 0) {
		printf("Cannot configure trigger\n");
		return;
	};
	printk("Configured for triggered sampling.\n");
	#endif

    while (1) {
        if (!IS_ENABLED(CONFIG_MPU6050_TRIGGER)) {
		int rc = process_mpu6050(mpu6050);

		if (rc != 0) {
			break;
		}
		k_sleep(K_SECONDS(0.1));
	}
		
		// the nn-features are stored into flash, and we don't want to load everything into RAM
        signal_t features_signal;
        features_signal.total_length = sizeof(features) / sizeof(features[0]);
        features_signal.get_data = &raw_feature_get_data;

        // invoke the impulse
        EI_IMPULSE_ERROR res = run_classifier(&features_signal, &result, true);
        printk("run_classifier returned: %d\n", res);

        if (res != 0) return 1;

        printk("Predictions (DSP: %d ms., Classification: %d ms., Anomaly: %d ms.): \n",
            result.timing.dsp, result.timing.classification, result.timing.anomaly);

        // print the predictions
        printk("[");
        for (size_t ix = 0; ix < EI_CLASSIFIER_LABEL_COUNT; ix++) {
            ei_printf_float(result.classification[ix].value);
#if EI_CLASSIFIER_HAS_ANOMALY == 1
            printk(", ");
#else
            if (ix != EI_CLASSIFIER_LABEL_COUNT - 1) {
                printk(", ");
            }
#endif
        }
#if EI_CLASSIFIER_HAS_ANOMALY == 1
        ei_printf_float(result.anomaly);
#endif
        printk("]\n");

        k_msleep(2000);
    }
}
